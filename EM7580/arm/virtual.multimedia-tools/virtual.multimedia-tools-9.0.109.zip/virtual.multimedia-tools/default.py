# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2016-present Team LibreELEC (https://libreelec.tv)

import xbmcgui

dialog = xbmcgui.Dialog()
dialog.ok('', 'This is a console-only addon')
